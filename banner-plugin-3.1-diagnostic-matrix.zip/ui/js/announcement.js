/* eslint-env browser */

function announcementObserverForMutation(selector) {
  return new Promise((resolve) => {
    if (document.querySelector(selector)) {
      return resolve(document.querySelector(selector));
    }

    const observer = new MutationObserver(() => {
      if (document.querySelector(selector)) {
        resolve(document.querySelector(selector));
        observer.disconnect();
      }
    });

    observer.observe(document.body, {
      childList: true,
      subtree: true,
    });

    window.setTimeout(() => {
      observer.disconnect();
      resolve(null);
    }, 4000);
  });
}

function announcementDisplay(toAnnounce) {
  const $ = window.jQuery;
  if (!toAnnounce || !$) {
    return;
  }
  announcementObserverForMutation(".padder-v").then((element) => {
    if (element) {
      $(element).before(toAnnounce);
    } else {
      $("body").prepend(toAnnounce);
    }
  });
}

function getPluginUrl(pluginHelper, path) {
  let url = pluginHelper.getPluginRestUrl(path);
  if (url && url.indexOf("http") !== 0 && url.charAt(0) !== "/") {
    url = "/" + url;
  }
  return url;
}

function probeEndpoint($, pluginHelper, name, path, dataType) {
  return $.ajax({
    url: getPluginUrl(pluginHelper, path),
    method: "GET",
    dataType: dataType,
    headers: {
      "X-XSRF-TOKEN": pluginHelper.getCsrfToken(),
    },
  })
    .done((data, status, xhr) => {
      console.info(
        "Announcement Plugin probe " + name + " OK:",
        xhr && xhr.status,
        data,
      );
    })
    .fail((xhr, status, error) => {
      console.error(
        "Announcement Plugin probe " + name + " FAILED:",
        status,
        error,
        xhr && xhr.status,
      );
    });
}

function announcementExec() {
  const pluginHelper = window.PluginHelper;
  const $ = window.jQuery;
  if (!pluginHelper) {
    console.error("Announcement Plugin: PluginHelper is not available");
    return;
  }
  if (!$) {
    console.error("Announcement Plugin: jQuery is not available");
    return;
  }

  probeEndpoint($, pluginHelper, "ping", "AnnouncementPlugin/ping", "text");
  probeEndpoint($, pluginHelper, "json", "AnnouncementPlugin/json", "json");
  probeEndpoint(
    $,
    pluginHelper,
    "configure",
    "AnnouncementPlugin/configure",
    "json",
  ).done((data) => {
    announcementDisplay(data);
  });
}

announcementExec();
